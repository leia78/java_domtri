
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PlateauDom extends JPanel {
	
	
	private Domino domi;
	private ArrayList<Domino> list;
	private Dimension dimension; // dimension de la fenêtre
	private Domino selectedDomino;
	private ArrayList<TriangleBtn> listeFleches;
	



	public PlateauDom() {
		
		// INSTANCIATIONS
		
		domi = new Domino(3,5, Orientation.GAUCHE, this);
		dimension = new Dimension(1200,900);
		listeFleches = new ArrayList<TriangleBtn>();
		
		setSize(dimension);
		
		list = new ArrayList<Domino>();
		

				
		// ECOUTEURS
		

		// Ajout des composants
		
		setLayout(null);
		


		domi.setPos(new Point(600, 300));
		domi.setLocation(domi.getPos());
		domi.addFleches();
		add(domi);
		
		
		list.add(new Domino(3,5, this));
		list.add(new Domino(2,4, this));
		list.add(new Domino(1,0, this));
		list.add(new Domino(5,6, this));
		
		printList(list);
		
//		for(Domino dodo : list) {
//			dodo.addFleches();
//		}
		
	}
	
	// Affiche une liste de dominos en partant d'une position de départ
	public void printList(ArrayList<Domino> list) {
		Point repere = new Point(dimension.width/4, 3*dimension.height/5);
		int decalage = Domino.taille + 40;
		
		for(Domino dom : list) {
			dom.setPos(new Point(repere.x, repere.y));
			dom.setLocation(dom.getPos());
			add(dom);
			repere.setLocation(repere.getX() + decalage, repere.getY());
		}
		
		// TEST AFICHAGE DES POSITIONS
//		for(Domino tqt : list) {
//			System.out.println(tqt.getPos().x+ "," +tqt.getPos().y);
//		}
	}
	
	
//	// ajoute les flèches au domino et les affiche autour du domino
//	public void addFleches(Domino dom)
//	{
//		Point pos = new Point(0,0);
//		
//		// Détermination du repère dans lequel on part pour placer nos flèches
//		
//		if(dom.getOrientation() == Orientation.DROITE) {
//			pos.setLocation(dom.getPos().getX() + Domino.taille, dom.getPos().getY());
//		}
//		else if(dom.getOrientation() == Orientation.BAS)
//		{
//			pos.setLocation(dom.getPos().getX(), dom.getPos().getY() + Domino.taille);
//		}
//		else
//		{
//			pos.setLocation(dom.getPos().getX(), dom.getPos().getY());
//		}
//			
//		// Création des flèches
//		
//		if(dom.getOrientation() != Orientation.HAUT) { // ajout flèche bas
//			listeFleches.add(new TriangleBtn(Orientation.BAS, new Point(pos.x, pos.y + Domino.taille)));
//			add(listeFleches.get(listeFleches.size()-1));
//			}
//		if(dom.getOrientation() != Orientation.BAS) { // ajout flèche haut
//			listeFleches.add(new TriangleBtn(Orientation.HAUT, new Point(pos.x, pos.y - Domino.taille)));
//			add(listeFleches.get(listeFleches.size()-1));
//			}
//		if(dom.getOrientation() != Orientation.GAUCHE) { // ajout flèche droite
//			listeFleches.add(new TriangleBtn(Orientation.DROITE, new Point(pos.x + Domino.taille, pos.y)));
//			add(listeFleches.get(listeFleches.size()-1));
//			}
//		if(dom.getOrientation() != Orientation.DROITE) { // ajout flèche gauche
//			listeFleches.add(new TriangleBtn(Orientation.GAUCHE, new Point(pos.x - Domino.taille, pos.y)));
//			add(listeFleches.get(listeFleches.size()-1));
//			}
//	}

	
	
	
	// PAINT COMPONENT


	public void paintComponent(Graphics g) {
		super.paintComponent(g);
				
		g.setColor(Color.white);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
//		g.setColor(Color.BLACK);
//		g.fillOval(120, 120, 50, 50);
	}
	

	public Domino getDomi() {
		return domi;
	}




	public void setDomi(Domino dom) {
		this.domi = dom;
	}

	public Dimension getDimension() {
		return dimension;
	}

	public void setDimension(Dimension dimension) {
		this.dimension = dimension;
	}
	
	public Domino getSelectedDomino() {
		return selectedDomino;
	}

	public void setSelectedDomino(Domino selectedDomino) {
		this.selectedDomino = selectedDomino;
	}

	public ArrayList<TriangleBtn> getListeFleches() {
		return listeFleches;
	}

	public void setListeFleches(ArrayList<TriangleBtn> listeFleches) {
		this.listeFleches = listeFleches;
	}


}