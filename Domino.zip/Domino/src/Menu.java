import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class Menu extends JFrame {

	private JPanel contentPane;

	 // Launch the application 

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	
	//creation du frame
	public Menu() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//DISPOSE_ON_CLOSE pour pouvoir fermer la fenetre apres 
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel(); 
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//creation du bouton domino et son action listerner qui ferme la fenetre principale du menu et ouvre une autre 
		JButton btnDomino = new JButton("Domino");
		btnDomino.setBounds(90, 235, 125, 38);
		contentPane.add(btnDomino);
		btnDomino.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MenuDomino menu = new MenuDomino();
				dispose();
				menu.setVisible(true);
				
				
				
			}
		});
		
		
		//creation du boutton Triominos et son action listener
		JButton btnTriominos = new JButton("Triominos");
		btnTriominos.setBounds(242, 235, 125, 38);
		contentPane.add(btnTriominos);
		btnTriominos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MenuDomino menu = new MenuDomino();
				dispose();
				menu.setVisible(true);
			}
		});
		
		//Jlabel pour l'image du fond
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setIcon(new ImageIcon("/Users/cyrine/eclipse-workspace/Domino/fond.png"));
		lblNewLabel.setBounds(6, 0, 444, 273);
		contentPane.add(lblNewLabel);
	}
	


}



