import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class MenuDomino extends JFrame {

	private JPanel contentPane;

	
	 // Launch the application.
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuDomino frame = new MenuDomino();
					
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	 //Creation du frame
	 
	public MenuDomino() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 204, 204)); 
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//creation bouton MultiPlayer qui ouvre la fenetre pseudo et ferme l'ancienne 
		JButton btnMultiPlayer = new JButton("Multiplayer");
		btnMultiPlayer.setBounds(146, 112, 146, 29);
		contentPane.add(btnMultiPlayer);
		btnMultiPlayer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Pseudos pseudo= new Pseudos();
				dispose();
				pseudo.setVisible(true);

			}
		});
	
		
		JButton btnScores = new JButton("Scores");
		btnScores.setBounds(146, 153, 146, 29);
		contentPane.add(btnScores);
		btnScores.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				

			}
		});
	
		
		JButton btnRetour = new JButton("Retour");
		btnRetour.setBounds(146, 194, 146, 29);
		contentPane.add(btnRetour);
		btnRetour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Menu menu=new Menu();
				dispose();
				menu.setVisible(true);

			}
		});
		
		
		JButton btnSingleLayer = new JButton("Single Player");
		btnSingleLayer.setBounds(146, 70, 146, 29);
		contentPane.add(btnSingleLayer);
		btnSingleLayer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
	
		
	}

}
