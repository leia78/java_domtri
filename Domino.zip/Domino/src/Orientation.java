public enum Orientation {
	HAUT,
	BAS,
	GAUCHE,
	DROITE;
}