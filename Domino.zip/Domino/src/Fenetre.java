
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Fenetre extends JFrame {
	
	private PlateauDom plateauDom;

	public Fenetre()
	{		
		// INSTANCIATIONS
		
		plateauDom = new PlateauDom();
		
		
		// ECOUTEURS
		
		

		// INITIALISATION DE LA FENETRE
		
		this.setTitle("Domino Day"); // titre de la fenêtre
		this.setSize(plateauDom.getDimension()); // largeur & hauteur
		this.setLocationRelativeTo(null); // centrer la fenêtre
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // dire que la croix ferme le processus
		
		
		this.afficherEcran(plateauDom); // définir container en tant que contenu "principal"
		setBackground(Color.PINK);
	}
	
	
	public void afficherEcran(JPanel ecran) {
		setContentPane(ecran);
		repaint();
		invalidate();
		setVisible(true); // TRES IMPORTANT
	}

}